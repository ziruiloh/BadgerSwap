package com.codewithfk.chatooz_android.utils

object Keys {
    const val APP_ID: Long = your app id
    const val APP_SIGN = "your app sign"
}